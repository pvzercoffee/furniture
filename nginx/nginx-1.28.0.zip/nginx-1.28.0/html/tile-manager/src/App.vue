<template>
  <upload />
</template>
<script lang="ts" setup>
import tile from './components/tile.vue'
import upload from './components/upload.vue'
</script>

<style scoped></style>
